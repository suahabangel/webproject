import React from 'react';
export default function Page() { return <div><h1>플로우차트</h1></div>; }