// src/components/simulations/FluidSimulation.js
import React, { useRef, useEffect } from 'react';
import './FluidSimulation.css';

const FluidSimulation = () => {
  const canvasRef = useRef(null);
  
  useEffect(() => {
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    
    // 캔버스 크기 설정
    canvas.width = canvas.offsetWidth;
    canvas.height = canvas.offsetHeight;
    
    // 시뮬레이션 설정
    const GRID_SIZE = 80;
    const PARTICLE_COUNT = 1000;
    const DYE_RESOLUTION = 512;
    
    // 색상 설정
    const COLORS = [
      { r: 0, g: 149, b: 233 },  // 파란색 - 정상 데이터 흐름
      { r: 255, g: 61, b: 87 },  // 빨간색 - 위험 데이터 흐름
      { r: 255, g: 211, b: 0 }   // 노란색 - 경고 데이터 흐름
    ];
    
    // 유체 시뮬레이션 관련 배열
    let velocity = [];
    let pressure = [];
    let density = [];
    
    // 배열 초기화
    const initializeArrays = () => {
      velocity = Array(GRID_SIZE * GRID_SIZE * 2).fill(0);
      pressure = Array(GRID_SIZE * GRID_SIZE).fill(0);
      density = Array(DYE_RESOLUTION * DYE_RESOLUTION * 4).fill(0);
    };
    
    // 유체 시뮬레이션 단계
    const simulationStep = () => {
      // 속도 업데이트
      updateVelocity();
      
      // 밀도 확산
      diffuseDensity();
      
      // 압력 계산
      solvePressure();
      
      // 결과 렌더링
      renderSimulation();
    };
    
    // 속도 업데이트 함수
    const updateVelocity = () => {
      // 나비에-스톡스 방정식 기반 속도 업데이트 로직
      // 실제 구현에서는 더 복잡한 계산이 포함됨
      for (let i = 0; i < GRID_SIZE * GRID_SIZE * 2; i += 2) {
        // 난류 및 와류 시뮬레이션
        const x = Math.floor(i / 2) % GRID_SIZE;
        const y = Math.floor(i / 2 / GRID_SIZE);
        
        // 중앙에 와류 생성 (EMR 시스템 표현)
        const centerX = GRID_SIZE / 2;
        const centerY = GRID_SIZE / 2;
        const dx = x - centerX;
        const dy = y - centerY;
        const distance = Math.sqrt(dx * dx + dy * dy);
        
        if (distance < GRID_SIZE / 4) {
          // 반시계 방향 회전 생성 (보안 위협 표현)
          velocity[i] = -dy / (distance + 1) * 0.2;
          velocity[i+1] = dx / (distance + 1) * 0.2;
        }
        
        // 오른쪽 하단에 난류 생성 (의료장비 네트워크 표현)
        if (x > GRID_SIZE * 0.6 && y > GRID_SIZE * 0.6) {
          velocity[i] += (Math.random() - 0.5) * 0.4;
          velocity[i+1] += (Math.random() - 0.5) * 0.4;
        }
      }
    };
    
    // 밀도 확산 함수
    const diffuseDensity = () => {
      // 보안 확산 모델 구현
      for (let i = 0; i < DYE_RESOLUTION * DYE_RESOLUTION * 4; i += 4) {
        const x = Math.floor(i / 4) % DYE_RESOLUTION;
        const y = Math.floor(i / 4 / DYE_RESOLUTION);
        
        // 정규화된 좌표
        const nx = x / DYE_RESOLUTION;
        const ny = y / DYE_RESOLUTION;
        
        // 속도장에서 보간된 속도 값 가져오기
        const vx = getInterpolatedVelocity(nx, ny, 0);
        const vy = getInterpolatedVelocity(nx, ny, 1);
        
        // 속도에 따라 색상 결정
        const v = Math.sqrt(vx * vx + vy * vy);
        let color;
        
        if (v > 0.3) {
          // 높은 속도 = 위험(빨간색)
          color = COLORS[1];
        } else if (v > 0.1) {
          // 중간 속도 = 경고(노란색)
          color = COLORS[2];
        } else {
          // 낮은 속도 = 정상(파란색)
          color = COLORS[0];
        }
        
        // 색상 설정
        density[i] = color.r / 255;
        density[i+1] = color.g / 255;
        density[i+2] = color.b / 255;
        density[i+3] = Math.min(v * 5, 1); // 투명도
      }
    };
    
    // 보간된 속도 가져오기
    const getInterpolatedVelocity = (nx, ny, component) => {
      const x = nx * GRID_SIZE;
      const y = ny * GRID_SIZE;
      
      const x0 = Math.floor(x);
      const y0 = Math.floor(y);
      const x1 = Math.min(x0 + 1, GRID_SIZE - 1);
      const y1 = Math.min(y0 + 1, GRID_SIZE - 1);
      
      const sx = x - x0;
      const sy = y - y0;
      
      const idx00 = (y0 * GRID_SIZE + x0) * 2 + component;
      const idx10 = (y0 * GRID_SIZE + x1) * 2 + component;
      const idx01 = (y1 * GRID_SIZE + x0) * 2 + component;
      const idx11 = (y1 * GRID_SIZE + x1) * 2 + component;
      
      // 양선형 보간
      return (1 - sx) * (1 - sy) * velocity[idx00] +
             sx * (1 - sy) * velocity[idx10] +
             (1 - sx) * sy * velocity[idx01] +
             sx * sy * velocity[idx11];
    };
    
    // 압력 계산 함수
    const solvePressure = () => {
      // 압력 계산 로직 (간단히 구현)
      for (let i = 0; i < GRID_SIZE * GRID_SIZE; i++) {
        const x = i % GRID_SIZE;
        const y = Math.floor(i / GRID_SIZE);
        
        // 속도의 발산 계산
        let divergence = 0;
        
        if (x > 0 && x < GRID_SIZE - 1 && y > 0 && y < GRID_SIZE - 1) {
          const vx_left = velocity[(y * GRID_SIZE + (x - 1)) * 2];
          const vx_right = velocity[(y * GRID_SIZE + (x + 1)) * 2];
          const vy_top = velocity[((y - 1) * GRID_SIZE + x) * 2 + 1];
          const vy_bottom = velocity[((y + 1) * GRID_SIZE + x) * 2 + 1];
          
          divergence = (vx_right - vx_left + vy_bottom - vy_top) / 2;
        }
        
        // 발산에 비례하는 압력
        pressure[i] = divergence * 0.5;
      }
    };
    
    // 렌더링 함수
    const renderSimulation = () => {
      // 캔버스 지우기
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      
      // 밀도 렌더링
      const imageData = ctx.createImageData(DYE_RESOLUTION, DYE_RESOLUTION);
      
      for (let i = 0; i < DYE_RESOLUTION * DYE_RESOLUTION * 4; i += 4) {
        imageData.data[i] = density[i] * 255;
        imageData.data[i+1] = density[i+1] * 255;
        imageData.data[i+2] = density[i+2] * 255;
        imageData.data[i+3] = density[i+3] * 255;
      }
      
      // 이미지 그리기
      ctx.putImageData(imageData, 0, 0);
      ctx.scale(canvas.width / DYE_RESOLUTION, canvas.height / DYE_RESOLUTION);
      
      // 추가 시각적 요소: 와류 표시
      if (Math.random() < 0.05) {
        drawVortexIndicators();
      }
    };
    
    // 와류 표시기 그리기
    const drawVortexIndicators = () => {
      // 원래 스케일로 복원
      ctx.scale(DYE_RESOLUTION / canvas.width, DYE_RESOLUTION / canvas.height);
      
      // EMR 시스템 와류 표시
      ctx.beginPath();
      ctx.arc(canvas.width * 0.5, canvas.height * 0.5, 50, 0, Math.PI * 2);
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.5)';
      ctx.lineWidth = 2;
      ctx.stroke();
      
      // 의료장비 네트워크 난류 표시
      ctx.beginPath();
      ctx.rect(canvas.width * 0.7, canvas.height * 0.7, 80, 80);
      ctx.strokeStyle = 'rgba(255, 61, 87, 0.7)';
      ctx.lineWidth = 2;
      ctx.stroke();
      
      // 다시 DYE_RESOLUTION에 맞게 스케일 조정
      ctx.scale(canvas.width / DYE_RESOLUTION, canvas.height / DYE_RESOLUTION);
    };
    
    // 애니메이션 시작
    const startAnimation = () => {
      initializeArrays();
      
      // 초기 밀도 설정
      for (let i = 0; i < DYE_RESOLUTION * DYE_RESOLUTION * 4; i += 4) {
        density[i+3] = 0.01; // 초기 투명도
      }
      
      // 타이머 시작
      let lastTime = Date.now();
      const animate = () => {
        const currentTime = Date.now();
        const deltaTime = (currentTime - lastTime) / 1000;
        lastTime = currentTime;
        
        // 시뮬레이션 단계 실행
        simulationStep();
        
        // 다음 프레임 요청
        requestAnimationFrame(animate);
      };
      
      animate();
    };
    
    // 시뮬레이션 시작
    startAnimation();
    
    // 캔버스 리사이즈 이벤트 처리
    window.addEventListener('resize', () => {
      canvas.width = canvas.offsetWidth;
      canvas.height = canvas.offsetHeight;
    });
    
    // 컴포넌트 언마운트 시 정리
    return () => {
      window.removeEventListener('resize', () => {});
    };
  }, []);
  
  return (
    <div className="fluid-simulation-container">
      <div className="simulation-info">
        <h2>유체역학 기반 의료정보 보안 시각화</h2>
        <p>나비에-스톡스 방정식을 사용한 데이터 흐름 모델링</p>
        <div className="legend">
          <div className="legend-item">
            <span className="legend-color" style={{ backgroundColor: 'rgb(0, 149, 233)' }}></span>
            <span className="legend-label">정상 데이터 흐름</span>
          </div>
          <div className="legend-item">
            <span className="legend-color" style={{ backgroundColor: 'rgb(255, 211, 0)' }}></span>
            <span className="legend-label">의심스러운 활동</span>
          </div>
          <div className="legend-item">
            <span className="legend-color" style={{ backgroundColor: 'rgb(255, 61, 87)' }}></span>
            <span className="legend-label">위험 데이터 흐름</span>
          </div>
        </div>
      </div>
      <div className="simulation-canvas-wrapper">
        <canvas ref={canvasRef} className="simulation-canvas"></canvas>
        <div className="overlay-markers">
          <div className="marker emr" title="전자의무기록 시스템">EMR</div>
          <div className="marker imaging" title="의료영상 시스템">영상</div>
          <div className="marker devices" title="의료장비 네트워크">장비</div>
          <div className="marker database" title="환자 데이터베이스">DB</div>
        </div>
      </div>
      <div className="simulation-controls">
        <div className="control-group">
          <label>시뮬레이션 속도</label>
          <input type="range" min="1" max="10" defaultValue="5" />
        </div>
        <div className="control-group">
          <label>지각성 (데이터 중요도)</label>
          <input type="range" min="1" max="10" defaultValue="7" />
        </div>
        <div className="control-group">
          <label>점성 (보안 정책 엄격성)</label>
          <input type="range" min="1" max="10" defaultValue="3" />
        </div>
      </div>
    </div>
  );
};

export default FluidSimulation;