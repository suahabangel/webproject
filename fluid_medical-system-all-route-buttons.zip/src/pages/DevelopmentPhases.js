
import React from 'react';
export default function DevelopmentPhases() {
  return <div><h1>개발 단계</h1><p>이 페이지는 프로젝트의 개발 단계를 설명합니다.</p></div>;
}
