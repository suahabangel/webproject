import React from 'react';
export default function Page() { return <div><h1>유체역학 의료 시스템</h1></div>; }