import React from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const buttonStyle = {
  padding: '10px 20px',
  margin: '10px',
  backgroundColor: '#007bff',
  color: 'white',
  textDecoration: 'none',
  borderRadius: '5px',
  display: 'inline-block'
};

const Overview = () => {
  const { role } = useAuth();

  return (
    <div style={{ textAlign: 'center', marginTop: '30px' }}>
      <h2>사용자 페이지</h2>
      <Link to="/flowchart" style={buttonStyle}>플로우차트로 이동</Link>
      <Link to="/development" style={buttonStyle}>개발 단계 보기</Link>
      <Link to="/fluid-medical" style={buttonStyle}>유체 의료 시스템</Link>
      <Link to="/navier-stokes" style={buttonStyle}>나비에-스토크스 방정식</Link>

      {role === 'admin' && (
        <>
          <h2 style={{ marginTop: '40px' }}>관리자 전용 페이지</h2>
          <Link to="/admin/dashboard" style={buttonStyle}>관리자 대시보드</Link>
          <Link to="/admin/manage-users" style={buttonStyle}>사용자 관리</Link>
          <Link to="/admin/manage-content" style={buttonStyle}>콘텐츠 관리</Link>
          <Link to="/admin/simulator" style={buttonStyle}>환자 시뮬레이터</Link>
        </>
      )}
    </div>
  );
};

export default Overview;
