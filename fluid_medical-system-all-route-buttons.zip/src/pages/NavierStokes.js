import React from 'react';
export default function Page() { return <div><h1>나비에-스톡스 시스템</h1></div>; }