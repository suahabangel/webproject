import React from 'react';
export default function Page() { return <div><h1>콘텐츠 관리</h1></div>; }