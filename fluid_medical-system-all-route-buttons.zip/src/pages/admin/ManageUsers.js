import React from 'react';
export default function Page() { return <div><h1>사용자 관리</h1></div>; }