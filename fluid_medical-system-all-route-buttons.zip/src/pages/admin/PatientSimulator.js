
import React, { useState } from 'react';

export default function PatientSimulator() {
  const [fileContent, setFileContent] = useState(null);
  const [fileType, setFileType] = useState(null);
  const [activeTab, setActiveTab] = useState('upload');

  const handleFileUpload = (e) => {
    const file = e.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    const extension = file.name.split('.').pop().toLowerCase();
    setFileType(extension);

    reader.onload = (event) => {
      const content = event.target.result;
      try {
        if (extension === 'json') {
          setFileContent(JSON.parse(content));
        } else if (extension === 'csv') {
          const lines = content.split('\n').map(line => line.split(','));
          setFileContent(lines);
        } else {
          setFileContent(content);
        }
      } catch (error) {
        setFileContent('파일 파싱 오류: ' + error.message);
      }
    };

    reader.readAsText(file);
  };

  const renderContent = () => {
    if (!fileContent) return null;

    if (fileType === 'json') {
      return <pre>{JSON.stringify(fileContent, null, 2)}</pre>;
    } else if (fileType === 'csv') {
      return (
        <table border="1" cellPadding="5">
          <tbody>
            {fileContent.map((row, idx) => (
              <tr key={idx}>
                {row.map((cell, cidx) => (
                  <td key={cidx}>{cell}</td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      );
    } else {
      return <pre>{fileContent}</pre>;
    }
  };

  return (
    <div>
      <h1>환자 시뮬레이터</h1>
      <div style={{ marginBottom: '1rem' }}>
        <button onClick={() => setActiveTab('upload')}>파일 업로드</button>
        <button onClick={() => setActiveTab('preview')}>데이터 미리보기</button>
      </div>

      {activeTab === 'upload' && (
        <div>
          <input type="file" accept=".json,.csv,.txt" onChange={handleFileUpload} />
        </div>
      )}

      {activeTab === 'preview' && (
        <div style={{ marginTop: '1rem' }}>
          {renderContent() || <p>먼저 파일을 업로드해주세요.</p>}
        </div>
      )}
    </div>
  );
}
