import React from 'react';
export default function Page() { return <div><h1>관리자 대시보드</h1></div>; }