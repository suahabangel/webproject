import React, { Suspense, lazy } from 'react';
import ReactDOM from 'react-dom/client';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';

const Overview = lazy(() => import('./pages/Overview'));
const Flowchart = lazy(() => import('./pages/Flowchart'));
const DevelopmentPhases = lazy(() => import('./pages/DevelopmentPhases'));
const FluidMedical = lazy(() => import('./pages/FluidMedical'));
const NavierStokes = lazy(() => import('./pages/NavierStokes'));

const AdminDashboard = lazy(() => import('./pages/admin/AdminDashboard'));
const ManageUsers = lazy(() => import('./pages/admin/ManageUsers'));
const ManageContent = lazy(() => import('./pages/admin/ManageContent'));
const PatientSimulator = lazy(() => import('./pages/admin/PatientSimulator'));

function AppRoutes() {
  const { role } = useAuth();

  return (
    <Routes>
      <Route path="/" element={<Overview />} />
      <Route path="/flowchart" element={<Flowchart />} />
      <Route path="/development" element={<DevelopmentPhases />} />
      <Route path="/fluid-medical" element={<FluidMedical />} />
      <Route path="/navier-stokes" element={<NavierStokes />} />

      {role === 'admin' && (
        <>
          <Route path="/admin/dashboard" element={<AdminDashboard />} />
          <Route path="/admin/manage-users" element={<ManageUsers />} />
          <Route path="/admin/manage-content" element={<ManageContent />} />
          <Route path="/admin/simulator" element={<PatientSimulator />} />
        </>
      )}

      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <BrowserRouter>
      <AuthProvider>
        <Suspense fallback={<div>Loading...</div>}>
          <AppRoutes />
        </Suspense>
      </AuthProvider>
    </BrowserRouter>
  </React.StrictMode>
);
