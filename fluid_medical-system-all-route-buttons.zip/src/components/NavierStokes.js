import React from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faWaveSquare, faChartLine, faBrain } from '@fortawesome/free-solid-svg-icons';

function NavierStokes() {
  return (
    <section id="navier-stokes" className="section">
      <h2>나비에-스톡스 시스템</h2>
      <div className="card">
        <p>나비에-스톡스 시스템은 유체의 흐름을 정확하게
        모델링하기 위한 나비에-스톡스 방정식을 기반으로 한 시스템입니다. 이 시스템은 유체의 패턴 인식, 와도 분석, 이상 감지 등 다양한 응용 프로그램을 지원합니다.</p>
        
        <h3>주요 구성 요소</h3>
        <ul>
          <li><strong>나비에-스톡스 시뮬레이션:</strong> 유체의 흐름을 시뮬레이션하여 정확한 결과를 도출합니다.</li>
          <li><strong>와도 분석:</strong> 유체의 와도를 분석하여 중요한 패턴을 감지합니다.</li>
          <li><strong>유체 패턴 인식:</strong> 유체의 패턴을 인식하여 이상 현상을 감지합니다.</li>
        </ul>
      </div>
      
      <div className="card-grid">
        <div className="card phase-card">
          <div className="phase-icon">
            <FontAwesomeIcon icon={faWaveSquare} />
          </div>
          <h3>나비에-스톡스 시뮬레이션</h3>
          <p>유체의 흐름을 정확하게 시뮬레이션하여 다양한 조건에서의 결과를 예측합니다.</p>
        </div>
        
        <div className="card phase-card">
          <div className="phase-icon">
            <FontAwesomeIcon icon={faChartLine} />
          </div>
          <h3>와도 분석</h3>
          <p>유체의 와도를 분석하여 중요한 패턴을 감지하고 흐름의 특성을 이해합니다.</p>
        </div>
        
        <div className="card phase-card">
          <div className="phase-icon">
            <FontAwesomeIcon icon={faBrain} />
          </div>
          <h3>유체 패턴 인식</h3>
          <p>기계 학습을 활용하여 유체의 패턴을 인식하고 이상 현상을 감지합니다.</p>
        </div>
      </div>
    </section>
  );
}

export default NavierStokes;