import React from 'react';
export default function Footer() {
  return <footer style={{ marginTop: '2rem' }}><hr /><p>&copy; 2025 Fluid Medical System</p></footer>;
}