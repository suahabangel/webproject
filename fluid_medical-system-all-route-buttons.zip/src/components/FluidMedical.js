import React from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faPills, faHeartbeat, faProjectDiagram } from '@fortawesome/free-solid-svg-icons';

function FluidMedical() {
  return (
    <section id="FluidMedical" className="section">
      <h2>유체역학 기반 의료 시스템</h2>
      <div className="card">
        <p>유체역학 기반 의료 시스템은 유체의 흐름과 관련된 물리적 원리를 의료 분야에 적용한 시스템입니다. 이 시스템은 약물 전달, 심혈관 질환 예측, 혈류 분석 등 다양한 의료 응용 프로그램을 지원합니다.</p>
        
        <h3>주요 구성 요소</h3>
        <ul>
          <li><strong>약물 전달 시스템:</strong> 확장 포아죄유 법칙을 적용하여 약물의 효율적인 전달을 모델링합니다.</li>
          <li><strong>심혈관 시스템:</strong> 진동 전단 지수를 활용하여 심혈관 질환의 위험을 예측합니다.</li>
          <li><strong>다중물리 통합:</strong> 시스템 해밀토니안을 통해 다양한 물리적 현상을 통합적으로 모델링합니다.</li>
        </ul>
      </div>
      
      <div className="card-grid">
        <div className="card phase-card fluid-medical">
          <div className="phase-icon">
            <FontAwesomeIcon icon={faPills} className="icon-fluid-medical" />
          </div>
          <h3>약물 전달 시스템</h3>
          <p>확장 포아죄유 법칙을 적용하여 인체 내 약물의 흐름을 분석하고 최적화합니다.</p>
        </div>
        
        <div className="card phase-card FluidMedical">
          <div className="phase-icon">
            <FontAwesomeIcon icon={faHeartbeat} className="icon-FluidMedical" />
          </div>
          <h3>심혈관 시스템</h3>
          <p>진동 전단 지수를 활용하여 혈관 내 혈류의 패턴을 분석하고 심혈관 질환의 위험을 예측합니다.</p>
        </div>
        
        <div className="card phase-card fluid-medical">
          <div className="phase-icon">
            <FontAwesomeIcon icon={faProjectDiagram} className="icon-FluidMedical" />
          </div>
          <h3>다중물리 통합</h3>
          <p>시스템 해밀토니안을 통해 다양한 물리적 현상을 통합적으로 모델링하여 복잡한 의료 시스템을 시뮬레이션합니다.</p>
        </div>
      </div>
    </section>
  );
}

export default FluidMedical;