import React from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { 
  faClipboardList, 
  faPencilRuler, 
  faCode, 
  faVial, 
  faWrench 
} from '@fortawesome/free-solid-svg-icons';

function Phases() {
  return (
    <section id="phases" className="section">
      <h2>개발 단계</h2>
      <div className="card-grid">
        <div className="card phase-card requirements">
          <div className="phase-icon">
            <FontAwesomeIcon icon={faClipboardList} className="icon-requirements" />
          </div>
          <h3>요구사항 분석</h3>
          <p>시스템의 기본 요구사항을 수집하고 분석하는 단계입니다.</p>
          <ul>
            <li>클라이언트 애플리케이션 요구사항</li>
            <li>보안 요구사항</li>
            <li>유체역학 의료 요구사항</li>
            <li>블록체인 및 마이크로서비스 요구사항</li>
          </ul>
        </div>
        
        <div className="card phase-card design">
          <div className="phase-icon">
            <FontAwesomeIcon icon={faPencilRuler} className="icon-design" />
          </div>
          <h3>설계</h3>
          <p>수집된 요구사항을 바탕으로 시스템 아키텍처를 설계하는 단계입니다.</p>
          <ul>
            <li>유체역학 기반 의료 시스템 설계</li>
            <li>나비에-스톡스 시스템 설계</li>
            <li>SQL 데이터베이스 설계</li>
            <li>로드 밸런싱 설계</li>
          </ul>
        </div>
        
        <div className="card phase-card implementation">
          <div className="phase-icon">
            <FontAwesomeIcon icon={faCode} className="icon-implementation" />
          </div>
          <h3>구현</h3>
          <p>설계를 바탕으로 실제 시스템을 구현하는 단계입니다.</p>
          <ul>
            <li>유체역학 기반 의료 시스템 구현</li>
            <li>나비에-스톡스 시스템 구현</li>
            <li>SQL 데이터베이스 구현</li>
            <li>로드 밸런싱 구현</li>
          </ul>
        </div>
        
        <div className="card phase-card verification">
          <div className="phase-icon">
            <FontAwesomeIcon icon={faVial} className="icon-verification" />
          </div>
          <h3>검증</h3>
          <p>구현된 시스템을 테스트하고 검증하는 단계입니다.</p>
          <ul>
            <li>시스템 테스트</li>
            <li>유체역학 기반 의료 시스템 테스트</li>
            <li>나비에-스톡스 시스템 테스트</li>
            <li>성능 및 확장성 테스트</li>
          </ul>
        </div>
        
        <div className="card phase-card maintenance">
          <div className="phase-icon">
            <FontAwesomeIcon icon={faWrench} className="icon-maintenance" />
          </div>
          <h3>유지보수</h3>
          <p>시스템을 지속적으로 관리하고 개선하는 단계입니다.</p>
          <ul>
            <li>유체역학 기반 의료 시스템 유지보수</li>
            <li>나비에-스톡스 시스템 유지보수</li>
            <li>데이터베이스 최적화</li>
            <li>성능 모니터링</li>
          </ul>
        </div>
      </div>
    </section>
  );
}

export default Phases;