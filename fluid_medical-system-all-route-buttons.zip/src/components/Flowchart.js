import React, { useEffect, useState } from 'react';
import mermaid from 'mermaid';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faSearchPlus, faSearchMinus, faSyncAlt } from '@fortawesome/free-solid-svg-icons';

function Flowchart() {
  const [scale, setScale] = useState(1);
  const scaleStep = 0.1;
  const minScale = 0.5;
  const maxScale = 2;

  useEffect(() => {
    mermaid.initialize({
      startOnLoad: true,
      theme: 'default',
      securityLevel: 'loose',
      flowchart: {
        useMaxWidth: false,
        htmlLabels: true
      }
    });
    
    // Re-render Mermaid diagram
    mermaid.contentLoaded();
    
    // Wait for the diagram to be rendered
    setTimeout(() => {
      const svg = document.querySelector('.mermaid svg');
      if (svg) {
        updateScale(svg, scale);
      }
    }, 1000);
  }, [scale]);

  const updateScale = (svg, newScale) => {
    if (svg) {
      svg.style.transform = `scale(${newScale})`;
      svg.style.transformOrigin = 'top left';
    }
  };

  const zoomIn = () => {
    if (scale < maxScale) {
      setScale(prevScale => prevScale + scaleStep);
    }
  };

  const zoomOut = () => {
    if (scale > minScale) {
      setScale(prevScale => prevScale - scaleStep);
    }
  };

  const resetZoom = () => {
    setScale(1);
  };

  const flowchartDefinition = `
flowchart TD
    %% Main Waterfall Model Stages
    Requirements[요구사항 분석] --> Design[설계]
    Design --> Implementation[구현]
    Implementation --> Verification[검증]
    Verification --> Maintenance[유지보수]
    
    %% Requirements Phase
    subgraph RequirementsPhase[요구사항 분석 단계]
        Client[클라이언트 애플리케이션] --> SecurityReq[보안 요구사항]
        Client --> ChatbotReq[AI 챗봇 요구사항]
        Client --> BlockchainReq[블록체인 요구사항]
        Client --> MicroserviceReq[마이크로서비스 요구사항]
        Client --> FluidSecurityReq[유체역학 보안 요구사항]
        Client --> FluidMedicalReq[유체역학 의료 요구사항]
        Client --> MultiPhysicsReq[다중물리 통합 요구사항]
        Client --> SQLReq[SQL 데이터베이스 요구사항]
        Client --> LoadBalancingReq[로드 밸런싱 요구사항]
        
        %% Navier-Stokes specific requirements
        FluidSecurityReq --> NavierStokesReq[나비에-스톡스 방정식 요구사항]
        NavierStokesReq --> VorticityAnalysisReq[와도 분석 요구사항]
        NavierStokesReq --> FluidPatternReq[유체 패턴 인식 요구사항]
        NavierStokesReq --> TurbulenceDetectionReq[난류 감지 요구사항]
        NavierStokesReq --> AnomalyDetectionReq[이상 패턴 감지 요구사항]
        
        %% Expand key medical requirements
        FluidMedicalReq --> DrugFlowReq[약물 흐름 분석]
        FluidMedicalReq --> DrugInteractionReq[약물 상호작용 모델링]
        FluidMedicalReq --> CardiovascularRiskReq[심혈관 질환 위험 예측]
        FluidMedicalReq --> DrugDeliveryReq[약물 전달 시스템 효율성]
    end
    
    %% Design Phase
    subgraph DesignPhase[설계 단계]
        %% Fluid Medical Design
        subgraph fluidMedicalDesign[유체역학 기반 의료 시스템 설계]
            DrugDeliverySystemDesign[약물 전달 시스템 설계]
            CardiovascularDesign[심혈관 시스템 설계]
            MultiPhysicsDesign[다중물리 통합 설계]
            
            %% Key mathematical models
            DrugDeliverySystemDesign --> EnhancedPoiseuilleLawDesign[확장 포아죄유 법칙 설계]
            MultiPhysicsDesign --> SystemHamiltonianDesign[시스템 해밀토니안 설계]
            CardiovascularDesign --> OscillatoryShearDesign[진동 전단 지수 설계]
        end
        
        %% Navier-Stokes Design
        subgraph navierStokesDesign[나비에-스톡스 시스템 설계]
            NavierStokesSimDesign[나비에-스톡스 시뮬레이션 설계]
            VorticityAnalysisDesign[와도 분석 설계]
            FluidPatternDesign[유체 패턴 인식 설계]
        end
    end
    
    %% Implementation Phase
    subgraph ImplementationPhase[구현 단계]
        %% Fluid Medical Implementation
        fluidMedicalImplement[유체역학 기반 의료 시스템 구현]
        fluidMedicalImplement --> DrugDeliverySystemImpl[약물 전달 시스템 구현]
        fluidMedicalImplement --> CardiovascularSystemImpl[심혈관 시스템 구현]
        
        %% Navier-Stokes Implementation
        navierStokesImplement[나비에-스톡스 시스템 구현]
        navierStokesImplement --> SimulationServiceImpl[시뮬레이션 서비스 구현]
        navierStokesImplement --> VorticityAnalysisImpl[와도 분석 서비스 구현]
    end
    
    %% Verification Phase
    subgraph VerificationPhase[검증 단계]
        SystemTest[시스템 테스트]
        SystemTest --> FluidMedicalTest[유체역학 기반 의료 시스템 테스트]
        SystemTest --> NavierStokesTest[나비에-스톡스 시스템 테스트]
    end
    
    %% Maintenance Phase
    subgraph MaintenancePhase[유지보수 단계]
        FluidMedicalMaintenance[유체역학 기반 의료 시스템 유지보수]
        NavierStokesMaintenance[나비에-스톡스 시스템 유지보수]
    end
    
    %% Styling
    classDef phaseHeader fill:#5D4037,stroke:#fff,stroke-width:1px,color:#fff;
    classDef requirements fill:#1976D2,stroke:#fff,stroke-width:1px,color:#fff;
    classDef design fill:#388E3C,stroke:#fff,stroke-width:1px,color:#fff;
    classDef implementation fill:#D32F2F,stroke:#fff,stroke-width:1px,color:#fff;
    classDef verification fill:#7B1FA2,stroke:#fff,stroke-width:1px,color:#fff;
    classDef maintenance fill:#F57C00,stroke:#fff,stroke-width:1px,color:#fff;
    classDef fluidmedical fill:#E91E63,stroke:#fff,stroke-width:1px,color:#fff;
    classDef navierstokes fill:#9C27B0,stroke:#fff,stroke-width:1px,color:#fff;
    
    class Requirements,Design,Implementation,Verification,Maintenance phaseHeader;
    class RequirementsPhase,FluidMedicalReq,DrugFlowReq,DrugInteractionReq,CardiovascularRiskReq,DrugDeliveryReq requirements;
    class DesignPhase,fluidMedicalDesign,DrugDeliverySystemDesign,CardiovascularDesign,MultiPhysicsDesign,EnhancedPoiseuilleLawDesign,SystemHamiltonianDesign,OscillatoryShearDesign design;
    class ImplementationPhase,fluidMedicalImplement,DrugDeliverySystemImpl,CardiovascularSystemImpl implementation;
    class VerificationPhase,FluidMedicalTest verification;
    class MaintenancePhase,FluidMedicalMaintenance maintenance;
    class fluidMedicalDesign,DrugDeliverySystemDesign,CardiovascularDesign,MultiPhysicsDesign,EnhancedPoiseuilleLawDesign,SystemHamiltonianDesign,OscillatoryShearDesign fluidmedical;
    class NavierStokesReq,VorticityAnalysisReq,FluidPatternReq,TurbulenceDetectionReq,AnomalyDetectionReq,navierStokesDesign,NavierStokesSimDesign,VorticityAnalysisDesign,FluidPatternDesign,navierStokesImplement,SimulationServiceImpl,VorticityAnalysisImpl,NavierStokesTest,NavierStokesMaintenance navierstokes;
  `;

  return (
    <section id="Flowchart" className="section">
      <h2>시스템 아키텍처 플로우차트</h2>
      <div className="controls">
        <button onClick={zoomIn}><FontAwesomeIcon icon={faSearchPlus} /> 확대</button>
        <button onClick={zoomOut}><FontAwesomeIcon icon={faSearchMinus} /> 축소</button>
        <button onClick={resetZoom}><FontAwesomeIcon icon={faSyncAlt} /> 원래 크기로</button>
      </div>
      <div className="mermaid">
        {flowchartDefinition}
      </div>
    </section>
  );
}

export default Flowchart;