import React from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

export default function Header() {
  const { role, loginAsAdmin, loginAsUser } = useAuth();
  return (
    <header>
      <nav>
        <Link to="/">개요</Link> | <Link to="/flowchart">플로우차트</Link> | <Link to="/development">개발 단계</Link> | <Link to="/fluid-medical">유체 의료</Link> | <Link to="/navier-stokes">나비에-스톡스</Link>
        {role === 'admin' && (
          <>
            {' | '}<Link to="/admin/dashboard">관리자</Link>
          </>
        )}
      </nav>
      <div>
        역할: {role}{' '}
        <button onClick={loginAsUser}>User</button>
        <button onClick={loginAsAdmin}>Admin</button>
      </div>
    </header>
  );
}