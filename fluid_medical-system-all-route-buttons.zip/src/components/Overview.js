import React from 'react';

function Overview() {
  return (
    <section id="overview" className="section">
      <h2>시스템 개요</h2>
      <div className="card">
        <p>이 시스템은 유체역학 원리를 의료 분야에 적용하여 약물 전달, 심혈관 질환 예측, 그리고 다양한 의료 응용 프로그램을 개발하는 통합 아키텍처입니다. 주요 기술 스택으로는 나비에-스톡스 방정식, 블록체인, 마이크로서비스, AI 챗봇, SQL 데이터베이스 및 로드 밸런싱이 포함됩니다.</p>
        <p>이 시스템은 워터폴 모델을 기반으로 개발되며, 요구사항 분석부터 유지보수까지 체계적인 단계를 거쳐 구현됩니다.</p>
      </div>
    </section>
  );
}

export default Overview;