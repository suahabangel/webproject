import React from 'react';
import { HashLink } from 'react-router-hash-link';
import './Navigation.css';

function Navigation() {
  return (
    <nav>
      <ul>
        <li><HashLink smooth to="#overview">개요</HashLink></li>
        <li><HashLink smooth to="#flowchart">플로우차트</HashLink></li>
        <li><HashLink smooth to="#phases">개발 단계</HashLink></li>
        <li><HashLink smooth to="#fluid-medical">유체역학 의료 시스템</HashLink></li>
        <li><HashLink smooth to="#navier-stokes">나비에-스톡스 시스템</HashLink></li>
      </ul>
    </nav>
  );
}

export default Navigation;