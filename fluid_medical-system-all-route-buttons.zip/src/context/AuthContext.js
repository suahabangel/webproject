import React, { createContext, useContext, useState } from 'react';

const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [role, setRole] = useState('admin'); // 'user' or 'admin'

  const loginAsAdmin = () => setRole('admin');
  const loginAsUser = () => setRole('user');

  return (
    <AuthContext.Provider value={{ role, loginAsAdmin, loginAsUser }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);