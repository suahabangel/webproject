import React from 'react';

function App_1() {
  return <div>App_1 is no longer used. Routing moved to index.js</div>;
}

export default App_1;
