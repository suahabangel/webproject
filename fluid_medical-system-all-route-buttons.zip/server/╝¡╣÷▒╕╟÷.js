// server/server.js
const express = require('express');
const { credential } = require('./config/azure');
const { connectDatabase } = require('./config/database');
const authRoutes = require('./routes/auth');
const patientsRoutes = require('./routes/patients');
const drugsRoutes = require('./routes/drugs');
const prescriptionsRoutes = require('./routes/prescriptions');
const simulationsRoutes = require('./routes/simulations');

const app = express();
app.use(express.json());

// Initialize database connection
let dbConnection;
(async () => {
  try {
    dbConnection = await connectDatabase();
    console.log('Database connection established');
  } catch (error) {
    console.error('Failed to connect to database', error);
  }
})();

// Register routes
app.use('/api/auth', authRoutes);
app.use('/api/patients', patientsRoutes);
app.use('/api/drugs', drugsRoutes);
app.use('/api/prescriptions', prescriptionsRoutes);
app.use('/api/simulations', simulationsRoutes);

// Start server
const PORT = process.env.PORT || 3001;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});