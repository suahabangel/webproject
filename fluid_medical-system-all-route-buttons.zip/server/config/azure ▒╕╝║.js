// server/config/azure.js
const { DefaultAzureCredential } = require('@azure/identity');
const { SecretClient } = require('@azure/keyvault-secrets');
const { BlobServiceClient } = require('@azure/storage-blob');

// Azure configuration parameters
const azureConfig = {
  tenantId: process.env.AZURE_TENANT_ID,
  clientId: process.env.AZURE_CLIENT_ID,
  keyVaultName: process.env.AZURE_KEY_VAULT_NAME,
  storageAccountName: process.env.AZURE_STORAGE_ACCOUNT_NAME
};

// Create Azure credential for authentication
const credential = new DefaultAzureCredential();

// Initialize Key Vault client
const keyVaultUrl = `https://${azureConfig.keyVaultName}.vault.azure.net`;
const keyVaultClient = new SecretClient(keyVaultUrl, credential);

// Initialize Blob Storage client
const blobServiceUrl = `https://${azureConfig.storageAccountName}.blob.core.windows.net`;
const blobServiceClient = new BlobServiceClient(blobServiceUrl, credential);

// Function to retrieve secrets from Azure Key Vault
async function getSecret(secretName) {
  try {
    const secret = await keyVaultClient.getSecret(secretName);
    return secret.value;
  } catch (error) {
    console.error(`Error retrieving secret ${secretName}:`, error);
    throw error;
  }
}

// Export Azure services and utilities
module.exports = {
  credential,
  keyVaultClient,
  blobServiceClient,
  getSecret,
  azureConfig
};